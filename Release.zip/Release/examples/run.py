from timeit import repeat
from tkinter import EXCEPTION
from matplotlib import pyplot as plt
import mpl_toolkits.mplot3d.axes3d as p3
from matplotlib import animation
from ast import literal_eval as make_tuple





def read_log(file_name:str):
    f = open(file_name , 'r')
    f_lines = f.read().split('\n')
    f_lines.pop()
    f.close()
    return f_lines


def convert_str2tup(inp:str):
   list_of_tuple = [make_tuple(i) for i in inp.split()[1:]]
   return list_of_tuple


def main():

    #initialize global vars
    LOG_FILE = 'final_12.txt'
    MAIN_LIST = read_log(LOG_FILE)
    print("--------------")
    print(MAIN_LIST)
    AGENT_NUMBER = MAIN_LIST[0]
    X_MAX = 100
    Y_MAX = 100
    Z_MAX = 100
    X_MIN = -100
    Y_MIN = -100
    Z_MIN = -100




    if AGENT_NUMBER == 0:
        raise EXCEPTION("YOUR NUMBER OF AGENTS IS ZERO !!")
    

    #start plot
    fig = plt.figure()
    ax = p3.Axes3D(fig)

    #limit x & y & z
    ax.set_xlim(X_MIN,X_MAX)
    ax.set_ylim(Y_MIN,Y_MAX)
    ax.set_zlim(Z_MIN,Z_MAX)

    #initalize points
    first_points = convert_str2tup(MAIN_LIST[1])

    array_points = []
    for p in first_points:
        new_poin, = ax.plot([p[0]],[p[1]],[p[2]],'o')
        array_points.append(new_poin)



    txt = fig.suptitle('')
    anim_running = True
    interval_speed = 1
    def onClick(event):
        print(event.key)
        #nonlocal interval_speed
        if event.key == 'enter':
            nonlocal anim_running
            if anim_running:
                ani.event_source.stop()
                anim_running = False
            else:
                ani.event_source.start()
                anim_running = True
        
        elif event.key == 'up':
            #interval_speed -= 100
            pass

        elif event.key == 'down':
            #interval_speed += 100
            pass

 
    def update_points(index, single_log, main_list, points):
        #in next version ====>>> comment next line and find single_log from input
        print(index)
        print("=======================================>>>>>>>>>>>>>>>>>>>>>>>>")
        single_log = main_list[index + 1]
        # print(single_log)
        time = single_log.split()[0]
        states = convert_str2tup(single_log)
        txt.set_text('travel time = {}'.format(time)) 


        # update properties
        for point,coordinate in zip(points, states):

            new_x = coordinate[0]
            new_y = coordinate[1]
            new_z = coordinate[2]
            point.set_data(new_x,new_y)
            point.set_3d_properties(new_z, 'z')
            print("({}, {}, {})".format(new_x, new_y, new_z))

        # return modified artists
        return points,txt


    fig.canvas.mpl_connect('key_press_event', onClick)

    # in next version ====>>>>> set frames=100 for instance. because its not important
    ani=animation.FuncAnimation(fig, update_points,
                                interval = interval_speed,
                                frames=len(MAIN_LIST) - 1,
                                fargs=("", MAIN_LIST , array_points),
                                repeat= False
                                )
    # #pause
    # anim.event_source.stop()

    # #unpause
    # anim.event_source.start()

    #save gif
    #writergif = animation.PillowWriter(fps=30) 
    #ani.save('result.gif', writer=writergif)

    plt.show()
    print("THE END...")



if __name__ == "__main__":
    main()
